#!|bin|bash
clear
echo -e '\e[96m'
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING.\'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING..|'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING.../'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING....\'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING.....|'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING....../'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING.......\'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING........|'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING........./'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING..........\'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING...........|'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING............/'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING.............\'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING..............|'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '              LOADING.............../'
sleep 0.1
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo -e '              \e[0m[\e[92m✔\e[0m] Installing ...'
echo " "

rm /data/data/com.termux/files/usr/etc/bash.bashrc

sleep 2

cp bash.bashrc /data/data/com.termux/files/usr/etc

sleep 2
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '
		██  ███ █   █ ███   █
		█ █ █ █ ██  █ █     █
		█ █ █ █ █ █ █ ███   █
		█ █ █ █ █  ██ █
		██  ███ █   █ ███   █ ' | lolcat
echo " "
echo " "
cowsay Exit and run after 5 seconds... | lolcat
echo " "
